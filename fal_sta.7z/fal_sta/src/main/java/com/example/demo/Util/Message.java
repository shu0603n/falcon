package com.example.demo.Util;

public class Message {
	
	public static String name ="aaaa";

}
