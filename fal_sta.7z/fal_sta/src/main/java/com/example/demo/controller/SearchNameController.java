package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;





@Controller
public class SearchNameController {
	
	/**
     * ユーザー情報 Repository
     */
    @Autowired
    UserRepository userRepository;

    /**
     * ユーザーが投稿した週報の一覧画面を表示
     * @param model Model
     * @return 週報情報一覧画面のHTML
     */
	@RequestMapping(value = "/SearchName", method = RequestMethod.GET)
    public String displayList(Model model) {
		List<User> searchNamelist = userRepository.findAll();
		model.addAttribute("searchNamelist", searchNamelist);
        return "html/empPage/listName";
    }
}